Nepřímá daň je taková daň, kterou státu platí jiná osoba než ta, která je dani podrobena. [[Daňový poplatník]] ji platí v rámci úhrady své spotřeby. A poté ji státu odvede příslušný obchodník ([[Plátce daně]]).

Opakem je přímá daň, kdy je poplatník přímo plátcem daně. Například [[Daň z příjmů fyzických osob (DPFO)]] či [[Daň z příjmů právnických osob (DPPO)]].