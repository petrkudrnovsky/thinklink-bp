- osoba je OBZP pokud má JEN [[Příjmy z kapitálového majetku]], [[Příjmy z nájmu]] a [[Ostatní příjmy]], tedy pokud není zaměstanec, OSVČ či státní pojištěnec
- tato "role" vychází z přepokladu, že každý by měl platit [[Sociální pojistné#1) VZP = veřejné zdravotní pojištění|Veřejné zdravotní pojištění]], nepřispívá-li za něj do systému stát

- pro OBZP tedy platí:
	- vyměřovací základ je minimální mzda
	- [[Sazba daně|sazba]] pojistného je stejná jako pro všechny ostatní (13,5 %, r. 2022)
	- rozhodné období je kalendářní měsíc