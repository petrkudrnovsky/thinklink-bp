 - daňový subjekt, je fyzická nebo právnická osoba, jejíž příjmy, majetek nebo činnost podléha dani
---
- může i nemusí být současně [[Plátce daně|plátcem]] daně
- u daně z příjmů ze závislé činnosti ve vztahu zaměstanec - zaměstanavatel je poplatníkem zaměstnanec, plátcem zaměstnavatel

### [[Daň z příjmů fyzických osob (DPFO)]]
- poplatníkem této daně je fyzická osoba (má bydliště na území ČR nebo se tu obvykle zdržuje - min 183 dní v roce)
	- pokud podmínka o bydlišti v ČR neplatí, vztahuje se daň jen na příjmy ze zdrojů v ČR
		- (= zkásneme cizince, kteří zde mají příjem)
- daňová povinnost se vztahuje i na příjmy ze zahraničí (= české občany zkásneme za všechny jejich příjmy)

### [[Daň z příjmů právnických osob (DPPO)]]
- poplatník je buď Daňový rezident nebo Daňový nerezident, podle toho, kde má sídlo. Tedy Daňový rezident je každá právnická osoba, která má v ČR sídlo nebo místo vedení.
	- Daňový rezident má neomezenou daňovou povinnost
		- mít neomozenou daňovou povinnost znamená, že jako poplatník bych měl v ČR v [[Daňové přiznání|daňovém přiznání]] uvést a zdanit všechny svoje příjmy a to tuzemské i celosvětové
- Daňový nerezident, má sídlo v zahraničí a zde má pouze omezenou daňovou povinnost
