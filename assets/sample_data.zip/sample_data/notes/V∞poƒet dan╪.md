1. mám předmět zdanění
2. - vyjmu položky, které mohou být vyjmuty z předmětu daně
3. = mám **[[Základ daně]]**
4. - odečtu položky, které jsou od daně osvobozeny
5. +- korekce (např. snížení o výdaje) - např. u [[Příjmy z nájmu|nájmu]] či [[Příjmy ze samostatné činnosti|samostatné činnosti]]
6. = mám základ daně po úpravách
7. ze základu odečítám [[Odpočet|odpočty]]
9. = základ daně po odpočtech
10. * [[Sazba daně]]
11. = částka daně před slevami
12. - [[Slevy na dani]]
13. = částka daně

- odpočty odčítám od dílčího základu daně
- slevy na dani odčítám až od samotné částky daně