- Aktuální hodnoty průměrné mzdy, [[Sazba daně|sazeb daně]], možných slev se nacházejí v daňových tabulkách daného roku
---

### Konkrétní příklad (r. 2022)
Hrubá mzda: 40 000Kč
- - sociální zabezpečení (6,5 %): 2 600Kč
- - veřejné zdravotní pojištění (4,5 %): 1 800Kč
- - [[Daň z příjmů fyzických osob (DPFO)|DPFO]] (15 %, 2. pásmo (od 48 * průměrná mzda je to 23 %)): 6 000Kč
	- - sleva na poplatníka: 2 570Kč
	- - DPFO po slevě: 3 430Kč

Čistá mzda: HM - SZ - VZP - (DPFO - slevy) = ČM