### Všichni jsou plátci
![[Pasted image 20221210172838.png]]

### Neplátce je na konci řetězce
![[Pasted image 20221210173554.png]]

### Neplátce je uprostřed řetězce
![[Pasted image 20221210173617.png]]

