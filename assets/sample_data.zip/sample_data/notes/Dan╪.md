Co to vůbec [[Daň]] je?

## Hlavní rozdělení
- [[Daň z příjmů fyzických osob (DPFO)]]
- [[Daň z příjmů právnických osob (DPPO)]]
- [[DPH]] - daň z přidané hodnoty
- [[Selektivní spotřební daně]]

## Výpočty
- [[Výpočet daně]]
- [[Výpočet čisté mzdy zaměstnance]]

## [[Druhy pracovních smluv]]

## [Zákony pro lidi](https://www.zakonyprolidi.cz/) - sbírka veškerých zákonů v ČR

### Moje daně
[[Co je za OSVČ potřeba poslat s DAP]]

