Tato osoba je registrovaná k [[DPH]], má nárok na [[Odpočet]] a zdaňuje svoje výstupy.

Registrační limit je obrat ve výši 1 mil. Kč (r. 2022) za 12 po sobě jdoucích měsíců. Po překročení limitu se musí osoba registrovat na finančním úřadě a odvádět DPH ze svých zdanitelných plnění. 

Pro některé firmy, které tohoto obratu nedosahují se ale stejně se jim vyplatí být plátci DPH, aby mohli lépe figurovat a obchodovat v [[Řetězce DPH|řetězci DPH]], pro ně existuje možnost se dobrovolně přihlásit k placení DPH.