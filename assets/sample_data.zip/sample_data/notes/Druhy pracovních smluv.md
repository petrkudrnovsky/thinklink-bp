[[Dohoda o provedení práce, DPP]]
[[Dohoda o pracovní činnost, DPČ]]
[[Smlouva na hlavní pracovní poměr, HPP]]