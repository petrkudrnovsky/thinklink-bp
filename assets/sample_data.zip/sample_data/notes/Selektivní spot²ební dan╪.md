Tyto daně postihují jen některé vybrané zboží, jejich základ je většinou vyjádřen ve fyzických jednotkách (litry, kusy...), jejich sazba je pevná a vázaná na počet/množství (Kč za jednotku). Sazba je také harmonizovaná v rámci EU (aby zboží z jedné země nebylo moc zvýhodněné oproti ostatním, existují výjimky, třeba daň z tichého vína - víno, které nešumí, nemá bublinky). 

Tyto daně existují kvůli omezení "škodlivé spotřeby" (cigarety, alkohol...), jsou také dobrým a stabilním příjmem státu.

V ČR máme spotřební daně:
- z minerálních olejů = olej z ropy, např. motorové benziny, střední a těžké plynové oleje
- z lihu, např. líh, lihoviny, destiláty
- z piva
- z vína a meziproduktů
- z tabákových výrobků a surového tabáku

- převážně nejvíc nese daň z tabáku a minerálních olejů (dohromady kolem 90%)

V ČR máme také energetické daně, kterými stát zatěžuje energetické produkty a elektřinu.
- daň ze zemního plynu a dalších plynů
- daň z pevných paliv (černé uhlí, koks, surové dřevo...)
- daň z elektřiny

Dále, [[Silniční daň]]