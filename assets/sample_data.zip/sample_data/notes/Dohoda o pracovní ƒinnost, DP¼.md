zdroj: https://www.idoklad.cz/blog/dohody-o-praci-dpp-dpc-jejich-limity-i-vyhody
***
- tato dohoda omezuje maximální počet odpracovaný hodin u jednoho zaměstavatele na 20 hodin/týden (polovina plného úvazku)
	- v praxi se to průměruje za celou dobu trvání DPČ (lze uzavřít maximálně na rok)
		- takže klidně můžu pracovat 40 hodin/týden, ale musí to sedět průměrově na 20 hodin/týden
	- klidně mohu přesáhnout limit 300 hodin/rok (narozdíl od [[Dohoda o provedení práce, DPP]])
- [[Sociální pojistné]] platím jen, když vydělám >3 500 Kč/měsíčně (r. 2022)