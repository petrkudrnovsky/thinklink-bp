= výdaje jsou vyšší než dosažené daňové příjmy
- může vzniknout jen u dvou dílčích základu daně [[Daň z příjmů fyzických osob (DPFO)|DPFO]]
	- [[Příjmy z nájmu]]
	- [[Příjmy ze samostatné činnosti]]
- o vzniklou daňovou ztrátu NEMŮŽE být snížen dílčí základ daně z [[Příjmy ze závislé činnosti|příjmů ze závislé činnosti]], všechny ostatní DZD sníženy být mohou

### Uplatnění daňové ztráty
- můžeme ji uplatnit v 5 bezprostředně následujících obdobích po roce, kdy byla ztráta vyměřena
NEBO
- ji můžeme nově uplatnit ve 2 zdaňovacích obdobích bezprostředně předcházejících zdaňovacího období (= zpětné uplatnění daňové ztráty)

- daňová ztráta je považována za položku odčitatelnou od [[Základ daně|základu daně]]
	- poplatník ji může odečíst v celé výši nebo jen její část

### Negativní dopad
- vykázání daňové ztráty a její uplatnění způsobí prodloužení doby pro daňovou kontrolu ze 3 na 8 let (+5 let = doba, kdy může být ztráta uplatněna)