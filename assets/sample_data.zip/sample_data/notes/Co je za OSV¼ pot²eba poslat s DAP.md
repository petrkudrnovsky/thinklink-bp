### [[Daňové přiznání]] 
- datovkou v .xml formátu na Finanční úřad Praha-východ: ID: 4sbn5j9
- je dobré si uschovat potvrzení o odeslání

### Přehled OSVČ o příjmech a výdajích pro OSSZ
- také datovkou na OSSZ Praha-východ: ID: yr2acxh

### Přehled OSVČ na zdravotní pojišťovnu, OZP
- ve formátu PDF na OZP: ID: q9iadw9
- zaplatit případný nedoplatek + nastavit pravidelný příkaz na zálohy na další rok (nebo to vynásobit 12-ti a zaplatit to najednou)
- VS: rodné číslo
- KS: 0858 (= platím přes účet)