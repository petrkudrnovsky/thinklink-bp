Situace, kdy [[Daňový poplatník]] má příjmy jak z [[Příjmy ze závislé činnosti]], tak i z [[Příjmy ze samostatné činnosti]]. 

V případě souběhu se hlavní samostatná činnost mění ve vedlejší samostatnou činnost.

Co se týče [[Sociální pojistné|sociálního pojistného]]
- minimální vyměřovací základ u VZP se bere jen u jedné činnosti (většinou u zaměstnání)
- u maximálního vyměřovacího základu u SZ dostávají přednost příjmy ze zaměstnání
