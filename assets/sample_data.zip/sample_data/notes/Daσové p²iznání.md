Formulář pro daňové přiznání spolu s dalšími formuláři najdu zde: https://adisspr.mfcr.cz/pmd/epo/formulare

Podává se zpravidla do 3 měsíců po skončení zdaňovacího období.
- do 1. 4. následující rok 
- do 2. 5. následující rok pro elektronická podání
- do 1. 7. pokud mám daňového poradce (je ale na FÚ potřeba dodat jeho plnou moc)

Kdy nejsem povinen podat DaP?
- pokud mám jen osvobozené příjmy
- pokud mám jen příjmy tvořící [[Samostatný základ daně (SZD)]]
- pokud mám fakt malý příjmy (míň než 15 000 Kč jako [[Základ daně]])
- pokud mám příjmy od hlavního zaměstnavatele a od ostatních mám fakt málo (do 6 000 Kč)