- když mám příjmy z držení finančního majetku

- tyto příjmy se dají zdanit
	- jako DZD příjmů z kapitálového majetku
		- klasicky se zdaňuje v daňovém přiznání poplatníka
		- příklady:
			- úroky z vkladů na účtech, které jsou určeny k podnikání
			- úroky z poskytnutých úvěrů a půjček (= přijaté úroky)
	- jako [[Samostatný základ daně (SZD)]]
		- zdaní se srážkou u zdroje
		- příklady:
			- úroky z vkladů na účtu, který není určen k podnikání
			- úroky plynoucí z jednorázového vkladu
			- úroky z dluhopisů, vkladních listů
			- podíly na zisku kapitálových korporací
			- podíly na zisku tichého společníka

- v tomto DZD si nelze uplatnit výdaje